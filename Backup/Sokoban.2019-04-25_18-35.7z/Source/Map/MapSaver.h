#ifndef MAPSAVER_H
#define MAPSAVER_H

namespace Sokoban {
;

class Map;

class MapSaver{
public:
    MapSaver();
    virtual ~MapSaver();



};

}

#endif // MAPSAVER_H
