#include "WallMapItem.h"

//WallMapItem :
//{

//}
