#ifndef WALLMAPITEM_H
#define WALLMAPITEM_H

#include <QWidget>
#include "MapItemBase.h"

namespace Sokoban {
;

class WallMapItem : public MapItemBase
{
public:
    WallMapItem();
};


} // end of namespace Sokoban
#endif // WALLMAPITEM_H
